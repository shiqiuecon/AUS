ECO351 Introduction to Econometrics — Shi Qiu — Fall 2026

26 lectures and 4 supplements. These PDFs match the public narrated lessons.
For narration, download an offline HTML lesson from https://shiqiuecon.github.io/AUS/ECO351/
Open the saved HTML file in a browser. Audio and transcripts are embedded.
Use Blackboard for assessments and submission instructions.
