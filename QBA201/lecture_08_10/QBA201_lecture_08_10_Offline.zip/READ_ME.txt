QBA201 - Lectures 8–10

1. Extract this ZIP into a folder before opening the lesson.
2. Open index.html in a normal web browser. Click Start narrated lesson.
3. The slides, narration and synchronized transcript work without internet.
4. Open QBA201_lecture_08_10_Slides.pdf for printable slides.

Keep the extracted files together. No login, server or paid API is needed.
Online lesson: https://shiqiuecon.github.io/AUS/QBA201/lecture_08_10/
