QBA201 — Lectures 15–17

Extract this ZIP and keep all three files together. Open index.html in your
browser for the slides, synthetic narration, and synchronized transcript.
The sampling activities, where present, also work without internet.
Open QBA201_lecture_15_17_Slides.pdf for printable slides.

Online lesson: https://shiqiuecon.github.io/AUS/QBA201/lecture_15_17/
