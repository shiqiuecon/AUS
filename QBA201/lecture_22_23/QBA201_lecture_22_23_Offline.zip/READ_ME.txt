Extract the ZIP and open index.html.
The graphs, narration and transcript work offline.
The slides PDF is included.
