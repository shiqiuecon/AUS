Extract all files and open index.html. Slides, narration and the synchronized transcript work offline.
