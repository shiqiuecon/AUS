Extract all files, then open index.html in a browser. The slides, narration and transcript work offline.
