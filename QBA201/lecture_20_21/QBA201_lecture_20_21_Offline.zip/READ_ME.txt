Extract the ZIP and open index.html. Slides, narration and transcript work offline. The related practice link opens the course website.
