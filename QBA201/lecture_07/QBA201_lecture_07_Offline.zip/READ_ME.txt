QBA201 — Lecture 7

Extract this ZIP and keep all three files together. Open index.html in your
browser for the slides, synthetic narration, and synchronized transcript.
The sampling activities, where present, also work without internet.
Open QBA201_lecture_07_Slides.pdf for printable slides.

Joining the voluntary class survey requires internet access.

Online lesson: https://shiqiuecon.github.io/AUS/QBA201/lecture_07/
