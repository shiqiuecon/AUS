Extract all files and open index.html in a browser. The slides, narration, transcript, and graph controls work offline.
